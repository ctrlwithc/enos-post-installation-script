packagesPacman=(
    "baobab"
    "font-manager"
    "gnome-browser-connector"
    "gnome-logs"
    "gnome-shell-extensions"
    "polkit-gnome"
    "sushi"
);

packagesYay=(
    "gdm-settings"
    "nautilus-open-any-terminal"
    "nwg-look-bin"
);
