go install github.com/zquestz/s@latest
