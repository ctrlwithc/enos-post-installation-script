git config --global user.name "HANK CHOU"
git config --global user.email "hengtse.me@gmail.com"
git config --global push.autoSetupRemote true
git config --global core.hooksPath .githooks/
git config --global push.followTags true
git config --global init.defaultBranch main
