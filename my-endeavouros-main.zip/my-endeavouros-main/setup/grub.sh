pwd="$PWD"
git clone https://github.com/vinceliuice/grub2-themes.git $HOME/grub2-theme
cd $HOME/grub2-theme
sudo ./install.sh -t vimix -s 1080p -i color
cd $pwd
